Balance & Activity Tracker — Excel export bundle
Created: 27/8/2026, 10:15:49 am
Selected WIP import: WIP 27.08.2026.CSV

Included workbooks:
- Selected WIP records
- Order Status
- Release Balance
- Computed FG
- Activity Wise
- Contractor Wise
- Plant Operation — Fabrication
- Plant Operation — Galvanization
- Daily Production Movement — Activity Wise
- Speed of Execution
- Job Wise Report
- Fabrication Load for TLT
- Contractor Performance
- Fabrication Report – Project Completion - TLT

Not available at export time:
- None

ZIP defaults:
- All WIP-based workbooks use the active global filters.
- Activity Wise reports Balance Wt in kilograms, matching the raw WIP file; Project Wise uses metric tonnes (MT).
- Activity Wise includes process-stage records and Finished Goods (blank Activity), but intentionally excludes Release Balance and Awaiting Assignment; its C row is active Cutting only.
- Job Wise uses Activity sorting and includes its lifecycle, stalled, and velocity columns.
- Fabrication Load uses its default weight-descending order; saved priority order is not applied.
- Contractor Performance applies the global filters that a movement ledger can represent (job, contractor, activity, date, search).
- Fabrication Completion includes all projects in the active job scope and the standard expanded stage columns.
- Plant Operation uses the all-sections / all-operations defaults, within the active global filters.

Not included because they do not provide an Excel workbook on the Reports page:
- Project Wise (Order Type and MFC display mode)
- Bucket List (MFC colour assignment and temporary hidden-project state)
- Activity Wise Net Balance Movement and Contractor Wise Net Balance Movement (history-window selection)
- Turnaround (warning-parameter settings)

Their individual Excel downloads remain available on the corresponding report pages.