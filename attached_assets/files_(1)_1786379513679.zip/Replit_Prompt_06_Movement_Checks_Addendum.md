# Addendum to Prompt 05 — cross-import movement checks for the Data Check tab

Send this **with** or **after** Prompt 05, not instead of it. Prompt 05 covers DC0–DC11, which
all validate a single import against itself. This adds a second section to the same tab that
compares an import against the one before it.

These are only possible now because the activity sequence has been established by tracking
individual marks between imports. It was not documented anywhere in the source files.

---

## THE SEQUENCE

```
C-init  ->  C-await  ->  C-cut  ->  RFI  ->  Q  ->  TS  ->  G / GB  ->  Y  ->  FG  ->  (despatched, leaves the file)
```

Established by matching marks between imports on project + mark number, restricted to marks
carrying a single activity on both days. Movement between 01-Aug and 10-Aug, 39,962 marks
tracked, 4,272 forward moves:

```
C-init -> C-await 223     RFI -> G  299     G  -> GB  60
C-await -> C-cut  181     TS  -> G   67     G  -> Y   59
C-cut  -> RFI     228     Q   -> TS  24     Y  -> FG  90
```

Every mark entering TS comes from RFI, Q, C-cut or NH. Every mark leaving TS goes to G, GB, Y
or FG. All 90 marks leaving Y went to FG. Nothing left FG at all.

`HG, NH, B, HAB, W` are fabrication and inspection activities that sit between C-cut and Q. They
do not have a strict order among themselves and should be treated as one rank.

---

## NEW CHECKS

### DC12 — backward activity movement (warning)

Count marks whose activity moved **backwards** in the sequence since the previous import. This
is rework: a mark offered for inspection and sent back for welding, or pulled out of temporary
stock for re-checking. It is legitimate and should be small.

Measured on three windows, using project + mark number matching:

| Window | Marks tracked | Forward | **Backward** | Backward weight |
|---|---|---|---|---|
| 08-Aug -> 10-Aug (2 days) | 42,997 | 918 | **16** | 4.122 MT |
| 05-Aug -> 08-Aug (3 days) | 42,643 | 2,530 | **10** | 2.772 MT |
| 01-Aug -> 10-Aug (9 days) | 39,962 | 4,272 | **17** | 4.346 MT |

The backward moves themselves, 01-Aug to 10-Aug:

```
RFI -> W    13 marks   3.058 MT      sent back for welding after being offered
RFI -> NH    2 marks   0.572 MT      sent back for notching
TS  -> Q     2 marks   0.716 MT      pulled from temp stock for re-check
```

Report the count, the weight, and the individual transitions. **Do not fail the import.** The
number to watch is whether it jumps — 15 to 20 marks per upload is normal, 500 would mean
something has gone wrong with the ERP or with the matching.

### DC13 — marks leaving Finished Goods (warning)

Over the 9-day window, **zero** marks left FG. Over shorter windows a handful appear (13 marks
FG -> Y between 08-Aug and 10-Aug, 1 mark FG -> G between 05-Aug and 08-Aug) and then disappear
again, which suggests same-day corrections rather than real movement.

FG should be terminal: material leaves it by being despatched, which removes it from the file
entirely. Report any mark that moves out of FG into an earlier activity, with project, mark,
weight and both activities.

### DC14 — marks that vanished without reaching FG (warning)

A mark should normally leave the file from FG, having been despatched. A mark that disappears
from an earlier activity has either been cancelled, re-numbered, or despatched without passing
through finished goods. Report the count and weight by last-known activity.

For reference, marks present on 08-Aug and absent on 10-Aug, by their last activity:

```
TS  186 marks  21.130 MT      FG  164 marks  51.726 MT
Q   147 marks  24.182 MT      G   128 marks  15.954 MT
GB   71 marks  13.119 MT      NH   63 marks   5.633 MT
Y    25 marks   4.777 MT      C-init 17 marks 43.210 MT
```

Note this measurement used a matching key that includes Job Card No., which changes when a mark
moves to a new operation — so most of these are not true disappearances. **Use the application's
own `mark_id` matching, as `diff.ts` and `contractorMovement.ts` do, not a key containing
`job_card_no`.** Report what that produces; the figures above are indicative only.

---

## IMPORTANT — mark identity

Do **not** match marks across imports on `pool_id`. `balance_qty` and `balance_wt` are inside
the row hash, so a mark that partially completes between uploads gets a new pool row. On a
working shop floor that is most marks, most days.

Use the same identity the existing movement code uses: `identityRawKey(markId, jobCardNo)` with
the bridge in `diff.ts`. If that bridge is unavailable in this context, say so rather than
substituting a different key — a different key produces different numbers and they will not be
comparable to anything else in the app.

---

## WHAT TO CHANGE

1. Add a second section to the Data Check tab, headed **Movement checks**, showing DC12, DC13
   and DC14 for the current import against the previous one.
2. Each row: rule, marks affected, weight, and a drill-down listing project, mark, weight,
   activity before and activity after.
3. Show the previous import's figure beside the current one, so a jump is visible.
4. State which two imports are being compared, by id and file date. If the previous import is
   the same file uploaded twice, say so and skip the comparison rather than reporting zero
   movement as if it were real.

## WHAT NOT TO CHANGE

- Do NOT change any bucket definition, the activity classification, the parser, the hashing or
  the mark-identity logic. This section reads existing data only.
- Do NOT treat backward movement as an error to be corrected in the data. It is rework.
- Do NOT hard-code the activity sequence as a validation that rejects imports. It is a warning
  framework only.
- Do NOT touch DC0–DC11 from Prompt 05, or the Project Wise MFC work.

## ACCEPTANCE CHECK

The tab must name the two imports being compared and report, for the most recent pair:

```
DC12  backward moves: count, weight, and the list of transitions
DC13  marks leaving FG: count, weight, list
DC14  vanished before FG: count and weight by last activity
```

Paste the figures and say which mark-identity key was used. My measurements above used
project + mark number and will not match exactly — I want to see what the application's own
matching produces, and if it differs by a lot, that is itself worth knowing.
