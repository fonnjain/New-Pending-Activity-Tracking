# Verify every WIP import against the source files

All available WIP and Order Review files have now been uploaded. Before any further changes,
I need to know which imports the app reports correctly and which it does not. Below are the
six-bucket figures measured directly from the source WIP files — not read from the app.

Every figure was computed with the agreed definitions:

```
Release Balance     Type = "Job Card Not Started" AND Job Card Status = "Initial"
Awaiting Assignment Type = "Job Card Not Started" AND Status = "Authorized" AND Contractor blank
Cutting             Type = "Job Card Not Started" AND Status = "Authorized" AND Contractor NOT blank
Quality Check       Type = "Job Card WIP" AND Activity in (HG, RFI, NH, B, HAB, W, Q, TS)
Galvanising         Type = "Job Card WIP" AND Activity in (G, GB, Y)
FG WIP              Type = "FG Pending For Dispatch"
```

TLT only (Order Nature = "Structure"), weight = Balance Wt. ÷ 1000, no other filter.

## MEASURED TARGETS (source of truth)

| Date | Release | Awaiting | Cutting | Quality Check | Galvanising | FG WIP | **Total** | TLT marks | NTLT total |
|---|---|---|---|---|---|---|---|---|---|
| 21-Jul | 2,538.863 | 985.133 | 1,611.919 | 1,921.510 | 2,935.120 | 1,400.577 | **11,393.122** | 60,276 | 6,796.975 |
| 24-Jul | 2,495.664 | 877.873 | 1,383.924 | 2,077.853 | 2,213.517 | 1,996.753 | **11,045.583** | 59,691 | 6,908.553 |
| 30-Jul | 2,112.271 | 1,104.513 | 1,414.718 | 1,867.583 | 1,933.288 | 2,280.720 | **10,713.093** | 58,321 | 6,483.514 |
| 31-Jul | 2,075.584 | 1,088.786 | 1,335.260 | 1,965.002 | 1,872.330 | 2,332.093 | **10,669.055** | 57,893 | 6,453.733 |
| 01-Aug | 2,057.398 | 1,017.222 | 1,344.800 | 1,966.340 | 1,854.658 | 2,400.993 | **10,641.411** | 58,144 | 6,454.600 |
| 05-Aug | 2,488.374 | 763.038 | 1,540.470 | 1,981.930 | 1,766.928 | 2,484.269 | **11,025.007** | 60,614 | 6,723.332 |
| 08-Aug | 2,283.393 | 887.813 | 1,219.760 | 2,191.165 | 1,618.790 | 2,596.892 | **10,797.813** | 59,497 | 6,406.121 |
| 10-Aug | 2,125.871 | 915.856 | 1,308.031 | 2,112.110 | 1,651.301 | 2,610.539 | **10,723.709** | 59,171 | 6,320.151 |

Earlier days, Release Balance only:

| Date | Release Balance | TLT marks |
|---|---|---|
| 11-Jul | 2,351.421 | 58,230 |
| 14-Jul | 2,209.658 | 56,643 |
| 18-Jul | 2,052.839 | 58,040 |
| 29-Jul | 2,148.912 | 58,844 |

**Unclassified marks are exactly zero on every one of these days.** The six buckets partition
the TLT file with no gap and no overlap. If any import reports a non-zero unclassified figure,
that is a defect regardless of what the totals say.

## WHAT I NEED — three separate outputs, please paste raw results

**1. The import list.** For every WIP import: id, source filename, the as-on date of the file,
and the row count. I need to know which physical file each import id corresponds to, and
whether the same file was imported more than once.

**2. Per-import bucket figures.** For each WIP import, the six bucket totals in MT (TLT only)
and the unclassified total. A table, one row per import.

**3. Release Balance table check.** For every import id:
`SELECT import_id, round(sum(release_balance_computed_mt)::numeric,3), count(*)
 FROM release_balance_wip GROUP BY import_id ORDER BY import_id;`

## KNOWN ISSUE TO CHECK SPECIFICALLY

The 04-Jul-2026 WIP file is the older **21-column** layout. It has **no `Type` column and no
`Job Card Status` column** — those were added to the export later. The six-bucket model cannot
be evaluated for that file at all.

If that file has been imported, tell me what its rows resolved to. My concern is that the
per-import type and status fall back to the pool row via COALESCE, which would mean a 04-Jul
import inherits **today's** classification for any mark that still exists — producing a
plausible-looking snapshot that never occurred. If that is what happens, say so plainly; the
right answer is probably to exclude pre-Type-column files from bucket reporting rather than to
show a fabricated split.

Check the same for every import whose source file has fewer than 24 columns.

## WHAT NOT TO CHANGE

Nothing at all in this message. This is a read-only verification pass. Do not fix anything you
find — report it and I will decide the order of work.

Do not change parsing, hashing, dedup, ageing, activity, the bucket definitions, milestones,
dispatch, or any stored table.

## WHAT I EXPECT

For each import whose source file is in the table above, the six figures should match to within
0.001 MT and the mark count should match exactly. Report every import that does not match, with
the app's figure and the target side by side.

Answer one numbered section at a time if the query is slow. Paste query output, not a summary
of it.
